#!/bin/sh
#

###############################################################################
# Domain Parameters
DOMAIN_HOME=/wls/domains/ClusterDomain

# AdminServer Parameters
AS_URL=http://192.168.101.22:7001

# Managed Server Parameters
MS_NAME=Server11
MS_IP=ispfserver1
MS_PORT=7003
MS_USER=weblogic
MS_PASS=qzgjj@wls

MS_URL=${MS_IP}:${MS_PORT}


# Java USER_MEM_ARGS
#USER_MEM_ARGS="-Djava.security.egd=file:/dev/./urandom -Xms1024m -Xmx1024m -XX:MaxPermSize=256m -Dfile.encoding=GBK"
export USER_MEM_ARGS="-Dhxyd.bzw=1 -Djava.security.egd=file:/dev/./urandom -Xms2048m -Xmx2048m -XX:MaxPermSize=512m -Dfile.encoding=GBK"
###############################################################################

case $( uname -s ) in
    "AIX")
        PORT_COUNT=$(netstat -an | grep ".${MS_PORT}" | grep -i listen | wc -l | xargs echo)
        ;;
    "HP-UX"|"Linux")
        PORT_COUNT=$(netstat -an | grep ":${MS_PORT}" | grep -i listen | wc -l)
        ;;
    *)
        echo "The operating system does not support!"
        exit 1
        ;;
esac
if [[ ${PORT_COUNT} != 0 ]]; then
	echo "WebLogicServer: Server may already be running"
	echo ""
	exit
else
	nohup ${DOMAIN_HOME}/bin/startManagedWebLogic.sh ${MS_NAME} ${AS_URL} > /dev/null 2> /dev/null &
	echo "WebLogicServer: Tool information is being logged in file"
	echo "                ${DOMAIN_HOME}/servers/${MS_NAME}/logs/${MS_NAME}.log"
	echo "WebLogicServer: Server state changed to <STARTING>"
	echo "WebLogicServer: Initializing self-tuning thread pool"
	echo "WebLogicServer: Server state changed to <ADMIN>"

	. ${DOMAIN_HOME}/bin/setDomainEnv.sh

	while :
	do
		java -classpath ${WEBLOGIC_CLASSPATH} weblogic.Admin -url ${MS_URL} -username ${MS_USER} -password ${MS_PASS} PING >/dev/null
		if [ "$?" = "0" ]; then
			echo "WebLogicServer: Server started in <RUNNING> mode"
			echo ""
			exit
		else
			sleep 3
		fi
	done
fi

