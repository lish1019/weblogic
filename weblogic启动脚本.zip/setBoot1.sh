#!/bin/sh
#

###############################################################################
# Domain Parameters
DM_HOME=/wls/domains
DM_NAME=ClusterDomain

# Authorized Parameters
USERNAME=weblogic
PASSWORD=wls12345

# Managed Server Parameters
MS_NAME_SCHEMA=Server
MS_NAME_CUR=11
MS_NAME_END=13

###############################################################################

while [ ${MS_NAME_CUR} -le ${MS_NAME_END} ]
do
	mkdir -p ${DM_HOME}/${DM_NAME}/bin/servers/${MS_NAME_SCHEMA}${MS_NAME_CUR}/security
	mkdir -p ${DM_HOME}/${DM_NAME}/servers/${MS_NAME_SCHEMA}${MS_NAME_CUR}/security
	echo "username=${USERNAME}" > ${DM_HOME}/${DM_NAME}/bin/servers/${MS_NAME_SCHEMA}${MS_NAME_CUR}/security/boot.properties
	echo "password=${PASSWORD}" >> ${DM_HOME}/${DM_NAME}/bin/servers/${MS_NAME_SCHEMA}${MS_NAME_CUR}/security/boot.properties
	cat ${DM_HOME}/${DM_NAME}/bin/servers/${MS_NAME_SCHEMA}${MS_NAME_CUR}/security/boot.properties
	echo "username=${USERNAME}" > ${DM_HOME}/${DM_NAME}/servers/${MS_NAME_SCHEMA}${MS_NAME_CUR}/security/boot.properties
	echo "password=${PASSWORD}" >> ${DM_HOME}/${DM_NAME}/servers/${MS_NAME_SCHEMA}${MS_NAME_CUR}/security/boot.properties
	cat ${DM_HOME}/${DM_NAME}/servers/${MS_NAME_SCHEMA}${MS_NAME_CUR}/security/boot.properties
	MS_NAME_CUR=`expr ${MS_NAME_CUR} + 1`
done

