#!/bin/sh
#

###############################################################################
# Scripts Parameters
SH_HOME=/scripts/wls

# Remote Server Parameters
RS_IP=blfserver2

###############################################################################

if [[ $(whoami) != "weblogic" ]]; then
	echo "The current user is not weblogic!"
	exit 1;
fi

if [[ $1 == "force" ]]; then
	ACTION=force_stop
else
	ACTION=stop
fi

${SH_HOME}/Server11.sh ${ACTION} 

ssh ${RS_IP} ${SH_HOME}/Server21.sh ${ACTION} 

${SH_HOME}/Server12.sh ${ACTION} 

ssh ${RS_IP} ${SH_HOME}/Server22.sh ${ACTION} 

${SH_HOME}/Server13.sh ${ACTION} 

ssh ${RS_IP} ${SH_HOME}/Server23.sh ${ACTION} 

${SH_HOME}/AdminServer.sh ${ACTION} 

