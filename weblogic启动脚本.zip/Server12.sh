#!/bin/sh
#

###############################################################################
# Please modify the parameters according to the actual situation

# Domain Parameters
DOMAIN_HOME=/wls/domains
DOMAIN_NAME=ClusterDomain

# AdminServer Parameters
AS_NAME=AdminServer
AS_IP=blfserver1
AS_PORT=7001
AS_USER=weblogic
AS_PASS=wls12345

# Managed Server Parameters
MS_NAME=Server12
MS_IP=blfserver1
MS_PORT=7004

# The maximum check count, 1 count = 3s
MAX_COUNT=60

# rotatelogs
case $( uname -s ) in
	"AIX")
		RL=/opt/freeware/sbin/rotatelogs
		;;
	"HP-UX"|"Linux")
		RL=/usr/sbin/rotatelogs
		;;
	*)
		echo "The operating system does not support!"
		exit 1
		;;
esac
ls -l ${RL} > /dev/null 2>&1
if [[ $? != 0 ]]; then
	echo "${RL} is not found!"
	exit 1
fi

# Java USER_MEM_ARGS
JAVA_VAR1="-Dwls.port=${MS_PORT}"
JAVA_VAR2="-Djava.security.egd=file:/dev/./urandom"
JAVA_VAR3="-Xms1024m -Xmx1024m -XX:MaxPermSize=256m"
JAVA_VAR4="-Dfile.encoding=GBK"
export USER_MEM_ARGS="${JAVA_VAR1} ${JAVA_VAR2} ${JAVA_VAR3} ${JAVA_VAR4}"

###############################################################################
# Please do not modify the following parameters

# Server running flag
STATS_FLAG=0

# The check count
CURRENT_COUNT=0

# WebLogic Server PID
WLS_PID=0

# WebLogic Server Message
WLS_MSG=""

# AdminServer URL
ASU=${AS_IP}:${AS_PORT}

# Domain Directy
DMD=${DOMAIN_HOME}/${DOMAIN_NAME}

# Server Log Directory
SLD=${DOMAIN_HOME}/${DOMAIN_NAME}/servers/${MS_NAME}/logs
SLN=${SLD}/nohup_%Y%m%d.log
SLNP=${SLD}/nohup_$(date +'%Y%m%d').log

# function boot
boot()
{
if [[ ! -f ${DMD}/servers/${MS_NAME}/security/boot.properties ]]; then
	mkdir -p ${DMD}/servers/${MS_NAME}/security/
	cat > ${DMD}/servers/${MS_NAME}/security/boot.properties <<- EOF
username=${AS_USER}
password=${AS_PASS}
	EOF
fi
}

# function start
start()
{
boot
status
if [[ ${STATS_FLAG} == 3 ]]; then
	[ -x ${RL} ] || ("${RL}��command not found !"; exit 5)
	mkdir -p ${SLD}
	(nohup ${DMD}/bin/startManagedWebLogic.sh ${MS_NAME} ${ASU} 2>&1 | ${RL} ${SLN} 86400) 0</dev/null 1>/dev/null 2>/dev/null & 
	echo "WebLogicServer: Tool information is being logged in file"
	echo "                ${SLNP}"
	echo "WebLogicServer: Server state changed to <STARTING>"
else
	echo ${WLS_MSG}
	echo ""
	exit ${STATS_FLAG}
fi

while [[ ${CURRENT_COUNT} -lt ${MAX_COUNT} ]]
do
	status
	if [[ ${STATS_FLAG} == 0 ]]; then
		echo ${WLS_MSG}
		echo ""
		exit ${STATS_FLAG}
	else
		let CURRENT_COUNT+=1;
		sleep 3
	fi
done
}

# function stop
stop()
{
${DMD}/bin/stopManagedWebLogic.sh ${MS_NAME}
echo ""
}

# function force_stop
force_stop()
{
status
kill -9 ${WLS_PID}
}

# function status
status()
{
case $( uname -s ) in
	"AIX")
		PORT_COUNT=$(netstat -an | grep ".${MS_PORT}" | grep -i listen | wc -l | xargs echo)
		;;
	"HP-UX"|"Linux")
		PORT_COUNT=$(netstat -an | grep ":${MS_PORT}" | grep -i listen | wc -l)
		;;
	*)
		echo "The operating system does not support!"
		exit 1
		;;
esac  

WLS_PID=$(ps -ef | grep "wls.port=${MS_PORT}" | grep -v grep | awk '{ print $2 }')
if [[ ! -n ${WLS_PID} ]]; then
	WLS_PID=0
fi

if [[ ${PORT_COUNT} != 0 && ${WLS_PID} != 0 ]]; then
	STATS_FLAG=0
	WLS_MSG="WebLogicServer: Server started in <RUNNING> mode, PID=${WLS_PID} !"
elif [[ ${PORT_COUNT} = 0 && ${WLS_PID} != 0 ]]; then
	STATS_FLAG=1
	WLS_MSG="WebLogicServer: Server started in <RUNNING> mode, PID=${WLS_PID}, but open port is not ${MS_PORT} !"
elif [[ ${PORT_COUNT} != 0 && ${WLS_PID} = 0 ]]; then
	STATS_FLAG=2
	WLS_MSG="WebLogicServer: Server is not running, but port ${MS_PORT} is open!"
else
	STATS_FLAG=3
	WLS_MSG="WebLogicServer: Server is not running!"
fi
}

case "$1" in
	start)
		start
		;;
	stop)
		stop
		;;
	force_stop)
		force_stop
		;;
	status)
		status
		echo ${WLS_MSG}
		echo ""
		;;
	restart)
		stop
		start
		;;
	force_restart)
		force_stop
		start
		;;
	*)
		echo $"Usage: $0 {start|stop|status|restart|force_stop|force_restart}"
		exit 1
esac

