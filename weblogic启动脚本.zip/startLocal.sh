#!/bin/sh
#

###############################################################################
# Scripts Parameters
SH_HOME=/scripts/wls

###############################################################################

if [[ $(whoami) != "weblogic" ]]
then
	echo "The current user is not weblogic!"
	exit 1;
fi

${SH_HOME}/startAdminServer.sh

${SH_HOME}/startServer11.sh

${SH_HOME}/startServer12.sh

${SH_HOME}/startServer13.sh

