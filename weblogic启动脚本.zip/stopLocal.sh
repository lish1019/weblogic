#!/bin/sh
#

###############################################################################
# Domain Parameters
DOMAIN_HOME=/wls/domains/ClusterDomain

# AdminServer Parameters
ADMIN_URL=192.168.101.22:7001

export ADMIN_URL
###############################################################################

if [[ $(whoami) != "weblogic" ]]
then
	echo "The current user is not weblogic!"
	exit 1;
fi

${DOMAIN_HOME}/bin/stopManagedWebLogic.sh Server11
echo ""

${DOMAIN_HOME}/bin/stopManagedWebLogic.sh Server12
echo ""

${DOMAIN_HOME}/bin/stopManagedWebLogic.sh Server13
echo ""

${DOMAIN_HOME}/bin/stopWebLogic.sh
echo ""

