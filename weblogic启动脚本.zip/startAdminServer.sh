#!/bin/sh
#

###############################################################################
# Domain Parameters
DOMAIN_HOME=/wls/domains/ClusterDomain

# AdminServer Parameters
AS_NAME=AdminServer
AS_IP=127.0.0.1
AS_PORT=7001
AS_USER=weblogic
AS_PASS=qzgjj@wls

AS_URL=${AS_IP}:${AS_PORT}

# Java USER_MEM_ARGS
#USER_MEM_ARGS="-Djava.security.egd=file:/dev/./urandom -Xms1024m -Xmx1024m -XX:MaxPermSize=256m -Dfile.encoding=GBK"
USER_MEM_ARGS="-Djava.security.egd=file:/dev/./urandom -Xms2048m -Xmx2048m -XX:MaxPermSize=512m -Dfile.encoding=GBK"

export USER_MEM_ARGS
###############################################################################

case $( uname -s ) in
    "AIX")
        PORT_COUNT=$(netstat -an | grep ".${AS_PORT}" | grep -i listen | wc -l | xargs echo)
        ;;
    "HP-UX"|"Linux")
        PORT_COUNT=$(netstat -an | grep ":${AS_PORT}" | grep -i listen | wc -l)
        ;;
    *)
        echo "The operating system does not support!"
        exit 1
        ;;
esac
if [[ ${PORT_COUNT} != 0 ]]; then
	echo "WebLogicServer: Server may already be running"
	echo ""
	exit
else
	nohup ${DOMAIN_HOME}/bin/startWebLogic.sh > /dev/null 2> /dev/null &
	echo "WebLogicServer: Tool information is being logged in file"
	echo "                ${DOMAIN_HOME}/servers/${AS_NAME}/logs/${AS_NAME}.log"
	echo "WebLogicServer: Server state changed to <STARTING>"
	echo "WebLogicServer: Initializing self-tuning thread pool"
	echo "WebLogicServer: Server state changed to <ADMIN>"

	. ${DOMAIN_HOME}/bin/setDomainEnv.sh

	while :
	do
		java -classpath ${WEBLOGIC_CLASSPATH} weblogic.Admin -url ${AS_URL} -username ${AS_USER} -password ${AS_PASS} PING >/dev/null 
		if [ "$?" = "0" ]; then
			echo "WebLogicServer: Server started in <RUNNING> mode"
			echo ""
			exit
		else
			sleep 3
		fi
	done
fi

